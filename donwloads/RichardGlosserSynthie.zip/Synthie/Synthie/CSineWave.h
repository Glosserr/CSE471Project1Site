#pragma once
#include "CAudionode.h"
class CSineWave :
	public CAudioNode
{
public:
	CSineWave(void);
	virtual ~CSineWave(void);

	//! Start audio generation
    virtual void Start();

    //! Generate one frame of audio
    virtual bool Generate();

    //! Set the sine wave frequency
    void SetFreq(double f) {m_freq = f;}

    //! Set the sine wave amplitude
    void SetAmplitude(double a) {m_amp = a;}

    // Add phase offset for vibrato
    void AddPhaseOffset(double offset) { m_phase += offset; }
    double GetPhase() const { return m_phase; }
    double GetFreq() const { return m_freq; }
    double GetAmp() const { return m_amp; }

private:
    double m_freq;
    double m_amp;
    double m_phase;
};

