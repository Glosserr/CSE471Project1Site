#include "pch.h"
#include "CInstrument.h"


CInstrument::CInstrument(void)
{
}


CInstrument::~CInstrument(void)
{
}
