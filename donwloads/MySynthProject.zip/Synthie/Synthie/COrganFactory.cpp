/**
 * \file COrganFactory.cpp
 * \brief Implements the organ factory for creating organ instruments.
 */

#include "pch.h"
#include "COrganFactory.h"

COrganFactory::COrganFactory()
{
}

COrganFactory::~COrganFactory()
{
}

std::shared_ptr<COrganInstrument> COrganFactory::CreateInstrument()
{
    // Create a new organ instrument instance
    auto instrument = std::make_shared<COrganInstrument>();
    return instrument;
}

void COrganFactory::XmlLoadInstrument(IXMLDOMNode* xml)
{
    // You can extend this later if the organ has extra XML parameters
    // such as stop selection, harmonic weights, or envelope shape.
    // For now, this function is a placeholder to match your Synthie pattern.
}
