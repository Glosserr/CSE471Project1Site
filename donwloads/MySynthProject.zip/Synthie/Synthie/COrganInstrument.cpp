#include "pch.h"
#include "COrganInstrument.h"
#include "CNote.h"
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

COrganInstrument::COrganInstrument()
{
    m_duration = 0.5;
    m_time = 0;

    // Create tonewheels dynamically
    for (int i = 0; i < 9; i++)
    {
        m_tonewheels[i] = new CSineWave();
    }

    // Initialize drawbars - default: 88 8000 000
    m_drawbars[0] = 8;
    m_drawbars[1] = 8;
    m_drawbars[2] = 8;
    m_drawbars[3] = 0;
    m_drawbars[4] = 0;
    m_drawbars[5] = 0;
    m_drawbars[6] = 0;
    m_drawbars[7] = 0;
    m_drawbars[8] = 0;

    // Initialize vibrato (enabled by default on Hammond B3)
    m_vibratoEnabled = true;
    m_vibratoFreq = 6.0;       // 6 Hz vibrato
    m_vibratoAmount = 0.005;   // 0.5% frequency variation
}

COrganInstrument::~COrganInstrument()
{
    // Delete all tonewheels
    for (int i = 0; i < 9; i++)
    {
        delete m_tonewheels[i];
    }
}

void COrganInstrument::SetNote(CNote* note)
{
    CComPtr<IXMLDOMNamedNodeMap> attributes;
    note->Node()->get_attributes(&attributes);
    long len;
    attributes->get_length(&len);

    double baseFreq = 440.0;

    for (int i = 0; i < len; i++)
    {
        CComPtr<IXMLDOMNode> attrib;
        attributes->get_item(i, &attrib);
        CComBSTR name;
        attrib->get_nodeName(&name);
        CComVariant value;
        attrib->get_nodeValue(&value);

        if (name == L"duration")
        {
            value.ChangeType(VT_R8);
            m_duration = value.dblVal;
        }
        else if (name == L"note")
        {
            baseFreq = CNote::NoteToFrequency(value.bstrVal);
        }
        else if (name == L"drawbars")
        {
            std::wstring drawbarStr = value.bstrVal;
            int dbIndex = 0;
            for (size_t j = 0; j < drawbarStr.length() && dbIndex < 9; j++)
            {
                if (drawbarStr[j] >= L'0' && drawbarStr[j] <= L'8')
                {
                    m_drawbars[dbIndex++] = drawbarStr[j] - L'0';
                }
            }
        }
        else if (name == L"vibrato")
        {
            // Accept "true"/"false" or "1"/"0"
            std::wstring vibratoStr = value.bstrVal;
            if (vibratoStr == L"false" || vibratoStr == L"0")
            {
                m_vibratoEnabled = false;
            }
            else
            {
                m_vibratoEnabled = true;
            }
        }
    }

    // Hammond B3 harmonic multipliers
    double multipliers[9] = { 0.5, 1.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0 };

    for (int i = 0; i < 9; i++)
    {
        m_tonewheels[i]->SetFreq(baseFreq * multipliers[i]);

        if (m_drawbars[i] == 0)
        {
            m_tonewheels[i]->SetAmplitude(0.0);
        }
        else
        {
            double dB = -3.0 * (8 - m_drawbars[i]);
            double amplitude = pow(10.0, dB / 20.0) * 0.1;
            m_tonewheels[i]->SetAmplitude(amplitude);
        }
    }
}

void COrganInstrument::Start()
{
    for (int i = 0; i < 9; i++)
    {
        m_tonewheels[i]->SetSampleRate(GetSampleRate());
        m_tonewheels[i]->Start();
    }

    m_time = 0;
}

bool COrganInstrument::Generate()
{
    const double vibratoFreq = 6.0;       // Hz
    const double vibratoDepth = 0.09;    // subtle pitch shift (~0.3%)

    double lfo = 0.0;
    if (m_vibratoEnabled)
    {
        lfo = sin(2.0 * M_PI * vibratoFreq * m_time);
    }

    double sumLeft = 0.0;
    double sumRight = 0.0;
    double activeAmplitude = 0.0;

    for (int i = 0; i < 9; i++)
    {
        m_tonewheels[i]->Generate();
        sumLeft += m_tonewheels[i]->Frame(0);
        sumRight += m_tonewheels[i]->Frame(1);
        activeAmplitude += m_drawbars[i] > 0 ? m_tonewheels[i]->GetAmp() : 0.0;
    }

    // Normalize if sum is too high to prevent clipping
    double normalization = 1.0;
    double maxAmp = fabs(sumLeft) > fabs(sumRight) ? fabs(sumLeft) : fabs(sumRight);
    if (maxAmp > 1.0)  // safe threshold
        normalization = 1.0 / maxAmp;

    sumLeft *= normalization;
    sumRight *= normalization;


    // Envelope shaping
    double env = 1.0;
    double attack = 0.05;
    double release = 0.1;
    if (m_time < attack)
        env = m_time / attack;
    else if (m_time > m_duration - release)
        env = (m_duration - m_time) / release;

    if (env < 0.0) env = 0.0;
    if (env > 1.0) env = 1.0;

    // --- Global Vibrato Application ---
    // Apply vibrato as slight phase modulation to summed output
    double vibratoPhase = 0.0;
    if (m_vibratoEnabled)
    {
        vibratoPhase = sin(2.0 * M_PI * vibratoFreq * m_time) * vibratoDepth * 2.0 * M_PI;
    }

    // Apply vibrato by modulating output with phase
    double vibratoMod = cos(vibratoPhase);

    // Subtle amplitude shimmer (optional)
    double vibratoAmp = 1.0 + (m_vibratoEnabled ? 0.01 * lfo : 0.0);

    m_frame[0] = sumLeft * env * vibratoMod * vibratoAmp;
    m_frame[1] = sumRight * env * vibratoMod * vibratoAmp;

    m_time += GetSamplePeriod();

    return m_time < m_duration;
}






