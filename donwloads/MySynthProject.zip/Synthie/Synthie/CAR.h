#pragma once
#include "CAudioNode.h"
#include <algorithm>
using namespace std;

class CAR : public CAudioNode
{
public:
    CAR() : m_source(nullptr), m_attack(0.05), m_release(0.05), m_duration(1.0){}
    virtual ~CAR() {}

    void SetSource(CAudioNode* src) { m_source = src; }
    void SetAttack(double a) { m_attack = a; }
    void SetRelease(double r) { m_release = r; }
    void SetDuration(double d) { m_duration = d; }
    void Start() override { m_time = 0; }

    bool Generate() override
    {
        if (!m_source) return false;

        m_source->Generate();
        double env = 1.0;

        // Attack
        if (m_time < m_attack) env = m_time / m_attack;

        // Release
        if (m_time > m_duration - m_release) env = (m_duration - m_time) / m_release;

        env = max(0.0, min(env, 1.0));

        m_frame[0] = m_source->Frame(0) * env;
        m_frame[1] = m_source->Frame(1) * env;

        m_time += GetSamplePeriod();
        return m_time < m_duration;
    }

private:
    CAudioNode* m_source;
    double m_attack;
    double m_release;
    double m_duration;
};