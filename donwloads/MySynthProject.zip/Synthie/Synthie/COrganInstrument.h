#pragma once
#include "CInstrument.h"
#include "CSineWave.h"
#include "CNote.h"

class COrganInstrument : public CInstrument
{
public:
    COrganInstrument();
    virtual ~COrganInstrument();

    void SetNote(CNote* note) override;
    void Start() override;
    bool Generate() override;

private:
    CSineWave* m_tonewheels[9];  // Changed to pointers
    int m_drawbars[9];
    double m_duration;
    double m_time;

    // Add vibrato members
    bool m_vibratoEnabled;
    double m_vibratoFreq;     // LFO frequency (typically 5-7 Hz)
    double m_vibratoAmount;   // Amount of frequency variation (0.005 = 0.5%)
};