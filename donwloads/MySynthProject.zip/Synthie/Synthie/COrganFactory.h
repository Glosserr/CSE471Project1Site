/**
 * \file COrganFactory.h
 * \brief Creates and configures organ instruments.
 */

#pragma once

#include "COrganInstrument.h"
#include "CNote.h"
#include <memory>

 /**
  * \class COrganFactory
  * \brief A simple class that creates COrganInstrument objects.
  *
  * Used by the synthesizer when parsing score XML.
  */
class COrganFactory
{
public:
    COrganFactory();
    virtual ~COrganFactory();

    /// Create an organ instrument instance
    std::shared_ptr<COrganInstrument> CreateInstrument();

    /// Load note parameters from XML into the organ instrument
    void XmlLoadInstrument(IXMLDOMNode* xml);
};
